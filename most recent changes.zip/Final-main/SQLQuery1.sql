ALTER TABLE user_details
    ALTER COLUMN passwords VARCHAR(50)
    COLLATE Latin1_General_CS_AS;